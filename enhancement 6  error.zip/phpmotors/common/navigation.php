
<ul>
  <li><a href="/phpmotors-demo/" title="PHP Motors home page">Home</a></li>
  <li><a href="#" title="clasic cars page">Classic</a></li>
  <li><a href="#" title="sports cars">Sports</a></li>
  <li><a href="#" title="sports utility vehicles">SUV</a></li>
  <li><a href="#" title="trucks">Trucks</a></li>
  <li><a href="#" title="used cars">Used</a></li>
</ul>