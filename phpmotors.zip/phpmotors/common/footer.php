
<p>&copy; PHP Motors, All rights reserved.</p>
<p>Images are believed to be "Fair Use". Notify the author if not and they will be removed.</p>
<p>Last Updated: <?php echo date('j F, Y',getlastmod());  ?></p>
