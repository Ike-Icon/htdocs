<div>
  <img src="/phpmotors/images/site/logo.png" alt="PHP Motors logo" id="logo">
  <a href="/phpmotors/accounts/index.php?action=login" title="Login or Register with PHP Motors" id="acc">My Account</a>
</div>